# TEE RATKAISUSI TÄHÄN:
def poista_pienemmat(lista, raja):
    return [luku for luku in lista if luku >= raja]