# tee ratkaisu tänne
def rivien_summat(matriisi: list):
    for rivi in matriisi:
        rivi.append(sum(rivi))