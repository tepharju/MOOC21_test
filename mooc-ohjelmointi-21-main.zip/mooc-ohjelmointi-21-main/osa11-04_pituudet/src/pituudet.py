# TEE RATKAISUSI TÄHÄN:
def pituudet(listat: list):
    return [len(l) for l in listat]