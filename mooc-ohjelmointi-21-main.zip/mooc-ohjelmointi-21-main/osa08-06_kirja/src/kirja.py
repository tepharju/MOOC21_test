# Tee ratkaisusi tähän:

class Kirja:
    def __init__(self, nimi, kirjoittaja, genre, kirjoitusvuosi):
        self.nimi = nimi
        self.kirjoittaja = kirjoittaja
        self.genre = genre
        self.kirjoitusvuosi = kirjoitusvuosi