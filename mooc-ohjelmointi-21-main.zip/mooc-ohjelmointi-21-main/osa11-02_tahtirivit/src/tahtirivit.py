# TEE RATKAISUSI TÄHÄN:
def tahtirivit(luvut: list):
    return [luku*"*" for luku in luvut]